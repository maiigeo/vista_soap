/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import sw.UserSW;
import sw.UserSW_Service;

/**
 *
 * @author HP
 */
public class OperacionesWS {

    static UserSW_Service servicio = new UserSW_Service();
    static UserSW cliente = servicio.getUserSWPort();
    public static String usuactual;

    public static String Login(String user, String password) {
        usuactual = user;
        return cliente.ingresar(user, password);
    }

    public static String Registro(String user, String password1, String password2, int cantidad) {

        return cliente.registrar(user, password1, password2, cantidad);
    }
    
    public static String Retiro(int cantidad){
        return cliente.retiro(cantidad, usuactual);
    }
    
    public static String Deposito(int cantidad){
        return cliente.deposito(cantidad, usuactual);
    }
    
    public static int Saldo(){
        return cliente.saldo(usuactual);
    }
    
}
