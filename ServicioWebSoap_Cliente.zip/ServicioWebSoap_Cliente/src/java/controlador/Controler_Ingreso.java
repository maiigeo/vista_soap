/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import modelo.OperacionesWS;
import vista.View_Inicio;

/**
 *
 * @author HP
 */
public class Controler_Ingreso {
    static View_Inicio inicio = new View_Inicio();
    
   public static void abrir(){
       inicio.setVisible(true);
   }
   
   public static void cerrar(){
       inicio.setVisible(false);
   }
   
    public static String ingresar(){
        return OperacionesWS.Login(inicio.getTxt_user().getText(), inicio.getTxt_password().getText());
    }
    
}
