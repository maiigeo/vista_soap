/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import modelo.OperacionesWS;
import vista.View_Saldo;

/**
 *
 * @author HP
 */
public class Controler_Saldo {
    static View_Saldo saldo= new View_Saldo();
    
    public static void abrir(){
        saldo.setVisible(true);
    }
    public static void cerrar(){
        saldo.setVisible(false);
    }
    
    public static String Saldo(){
        return String.valueOf(OperacionesWS.Saldo());
    }
    
    public static String Retiro_Deposito(){
        String mensaje = null;
        
        if(saldo.getRd_retiro().isSelected()){
            mensaje=OperacionesWS.Retiro(Integer.parseInt(saldo.getTxt_valor().getText()));
        }else
        if(saldo.getRd_deposito().isSelected()){
            mensaje=OperacionesWS.Deposito(Integer.parseInt(saldo.getTxt_valor().getText()));
        }
        return mensaje;
    }
}
