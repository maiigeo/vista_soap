/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import modelo.OperacionesWS;
import vista.View_Registro;

/**
 *
 * @author HP
 */
public class Controler_Registro {
    static View_Registro registro=new View_Registro();
    
    public static void abrir(){
        registro.setVisible(true);
    }
    public static void cerrar(){
        registro.setVisible(false);
    }
    public static String registra(){
        return OperacionesWS.Registro(registro.getTxt_user2().getText(), registro.getTxt_clave1().getText(),
                registro.getTxt_clave2().getText(), Integer.parseInt(registro.getTxt_saldo().getText()));
    }
    
}
